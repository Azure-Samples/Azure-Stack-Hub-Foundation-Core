#requires -Version 5.1
#requires -RunAsAdministrator
#requires -Modules @{ ModuleName="Az.Accounts"; ModuleVersion="2.0.1" }
#requires -Modules @{ ModuleName="Az.Compute"; ModuleVersion="0.10.0" }
#requires -Modules @{ ModuleName="Az.Network"; ModuleVersion="0.10.0" }
#requires -Modules @{ ModuleName="Az.Resources"; ModuleVersion="0.10.0" }
#requires -Modules @{ ModuleName="Az.Storage"; ModuleVersion="0.10.0" }

### -----------------------------------------
### Strings
### -----------------------------------------
Data Strings
{
# culture="en-US"
ConvertFrom-StringData @'
    # message
    MsgCreateVhdFolder = Creating directory {0}
    MsgVmName = VM Name: {0}
    MsgVmResourceGroup = VM Resource Group: {0}
    MsgOsDiskName = OS Disk Name: {0}
    MsgDataDiskNames = Data Disk Names: {0}
    MsgCreateNewContainer = Create new storage container {0}
    MsgShouldContinueStopVMConfirm = This cmdlet will stop the specified virtual machine. Do you want to continue?
    MsgShouldContinueStopVMOperation = Virtual machine stopping operation
    MsgCopyVHDTryTime = Try to copy VHD of disk {0} for the {1} time
    MsgUseAzCopy = Using AzCopy...
    MsgAzCopyDownloadVHD = Downloading {0} VHD from Azure Storage to local folder {1}
    MsgAzCopyUploadVHD = Uploading {0} VHD from local folder {1} to Azure Stack container {2}
    MsgUseAzStorageBlobCopy = Using AzureStorageBlobCopy...
    MsgAzStorageBlobCopyActivity = Exporting VHD of the managed disk {0} to Azure Stack container {1}
    MsgCreateTemplateDestFolder = Creating directory {0}
    MsgWriteIntoFile = Writing into {0}
    MsgShouldContinueOverwriteConfirm = This cmdlet will overwrite file {0}. Do you want to continue?
    MsgShouldContinueOverwriteOperation = File overwriting operation
    MsgSourceDiskVhdUris = Note that after successful failback deployment, you can safely delete the VHD files: {0}
    MsgDisksAttachedToTheVMToBeDeleted = The names of old disks attached to the specified target VM {0} are listed below, you can check and delete them manually if you think everything is OK after a successful failback:
    MsgShouldContinueDeleteVMConfirm = This cmdlet will delete VM {0} so that VM can be redeployed with failed-back disks. Do you want to continue?
    MsgShouldContinueDeleteVMOperation = Deleting VM Operation
    MsgDeleteVMOperationName = Delete VM

    # progress
    ProgressGetDiskInfo = Getting disk information of source VM
    ProgressGetTargetStorageContext = Getting target storage context
    ProgressStopVM = Stopping source VM {0}
    ProgressCopyVHD = Exporting VHD of the managed disk {0} to Azure Stack container {1}

    # warning
    WarningFailToDeleteLocalVhdFile = Fail to delete the downloaded VHD file {0}, please try to delete it manually. Exception: {1}
    WarningFailToCopyVHD = Fail to copy VHD of disk {0} for the {1} time, will retry after {2} seconds... Exception: {3}

    # error
    ErrorAzCopyPathInvalid = Provided AzCopy path {0} is invalid or is not a file
    ErrorStopVmFail = Stop source VM {0} failed: {1}
    ErrorStopVmCancel = Stop source VM {0} canceled
    ErrorWrongSourceDiskVhdUri = Provided source disk vhd uri at position {0} does not match disk {1}
    ErrorWrongSourceDiskVhdUrisCount = The number of disks attached to source VM is {0}, but {1} source disk vhd uri(s) provided
    ErrorInvalidStorageAccountType = Invalid Storage Account Type data retrieved for VM {0}
    ErrorOverwriteFileCancel = Overwrite file {0} canceled
    ErrorDeleteVMCancel = Delete VM {0} canceled. The ARM template and parameter file have been generated to {1} and {2}, you can manually delete the target VM and deploy the template
    ErrorFailToCopyVHD = Fail to copy VHD of disk {0} due to exception: "{1}"
    ErrorAzCopyParameterNotProvided = To use AzCopy, both AzCopyPath and VhdLocalFolder need to be provided.
'@
}

# Import localized strings
Import-LocalizedData Strings -FileName FailbackTool.Strings.psd1 -ErrorAction SilentlyContinue

### -----------------------------------------
### Constants
### -----------------------------------------
$SasExpiryDuration = "36000"
$SleepTime = "30"

$AzCopyServiceAPIVersion = "2017-11-09"

$SchemaVersion = "2018-05-01"
$VmArmAPIVersion = "2017-12-01"
$StorageAccountArmAPIVersion = "2017-10-01"
$NetworkArmAPIVersion = "2018-11-01"
$DiskArmAPIVersion = "2017-03-30"

$BootDiagnosticsTemplating = [ordered]@{
    diagnosticsProfile = [ordered]@{
        bootDiagnostics = [ordered]@{
            enabled = "[parameters('bootDiagnosticsEnabled')]"
            storageUri = "[parameters('bootDiagnosticsStorageUri')]"
        }
    }
}

$StorageAccountTemplating = [ordered]@{
    name = "[parameters('storageAccountName')]"
    type = "Microsoft.Storage/storageAccounts"
    apiVersion = $StorageAccountArmAPIVersion
    location = "[parameters('location')]"
    properties = [ordered]@{
        supportsHttpsTrafficOnly = "[parameters('storageAccountSupportsHttpsTrafficOnly')]"
    }
    sku = [ordered]@{
        name = "[parameters('storageAccountSkuName')]"
    }
    kind = "[parameters('storageAccountKind')]"
}

$VirtualNetworkTemplating = [ordered]@{
    type = "Microsoft.Network/virtualNetworks"
    name = "[parameters('virtualNetworkName')]"
    apiVersion = $NetworkArmAPIVersion
    location = "[parameters('location')]"
    properties = [ordered]@{
        addressSpace = [ordered]@{
            addressPrefixes = "[parameters('virtualNetworkAddressPrefixes')]"
        }
        subnets = @(
            [ordered]@{
                name = "[parameters('subnetName')]"
                properties = [ordered]@{
                    addressPrefix = "[parameters('subnetAddressPrefix')]"
                }
            }
        )
    }
}

$PublicIpAddressTemplating = [ordered]@{
    type = "Microsoft.Network/publicIPAddresses"
    apiVersion = $NetworkArmAPIVersion
    name = "[parameters('publicIpAddressName')]"
    location = "[parameters('location')]"
    sku = [ordered]@{
        name = "[parameters('publicIpAddressSkuName')]"
    }
    properties = [ordered]@{
        publicIPAllocationMethod = "[parameters('publicIPAllocationMethod')]"
        idleTimeoutInMinutes = "[parameters('idleTimeoutInMinutes')]"
        publicIpAddressVersion = "[parameters('publicIpAddressVersion')]"
    }
}

$OsDiskStorageProfile = [ordered]@{
    osType = "[parameters('osType')]"
    caching = "[parameters('osDiskCaching')]"
    createOption = "[parameters('diskCreateOption')]"
    managedDisk = [ordered]@{
        id = "[resourceId('Microsoft.Compute/disks', parameters('osDiskName'))]"
    }
}

$OsDiskTemplating = [ordered]@{
    type = "Microsoft.Compute/disks"
    apiVersion = $DiskArmAPIVersion
    name = "[parameters('osDiskName')]"
    location = "[parameters('location')]"
    properties = [ordered]@{
        creationData = [ordered]@{
            createOption = "Import"
            sourceUri = "[parameters('osDiskSourceUri')]"
        }
        osType = "[parameters('osType')]"
    }
}

$DataDiskStorageProfile = [ordered]@{
    copy = @(
        [ordered]@{
            name = "dataDisks"
            count = "[length(parameters('dataDiskNames'))]"
            input = [ordered]@{
                lun = "[parameters('dataDiskLuns')[copyIndex('datadisks')]]"
                name = "[parameters('dataDiskNames')[copyIndex('datadisks')]]"
                createOption = "[parameters('diskCreateOption')]"
                managedDisk = [ordered]@{
                    id = "[resourceId('Microsoft.Compute/disks/', parameters('dataDiskNames')[copyIndex('datadisks')])]"
                }
            }
        }
    )
}

$DataDiskTemplating = [ordered]@{
    type = "Microsoft.Compute/disks"
    apiVersion = $DiskArmAPIVersion
    name = "[parameters('dataDiskNames')[copyIndex('datadisks')]]"
    location = "[parameters('location')]"
    sku = [ordered]@{
        name = "[parameters('storageAccountSkuName')]"
    }
    properties = [ordered]@{
        creationData = [ordered]@{
            createOption = "Import"
            sourceUri = "[parameters('dataDiskSourceUri')[copyIndex('datadisks')]]"
        }
        diskSizeGB = "[parameters('dataDiskSizeGB')[copyIndex('datadisks')]]"
    }
    copy = [ordered]@{
        name = "datadisks"
        count = "[length(parameters('dataDiskNames'))]"
    }
}

function Copy-DiskVhd
{
    [OutputType([String])]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $SourceDiskName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $SourceDiskSas,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetContainerName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetContainerUri,

        [Parameter(Mandatory = $true, ParameterSetName="AzCopy")]
        [ValidateScript({$_ | Test-Path -IsValid})]
        [String]
        $AzCopyPath,

        [Parameter(Mandatory = $true, ParameterSetName="AzCopy")]
        [ValidateScript({$_ | Test-Path -IsValid})]
        [String]
        $VhdLocalFolder,

        [Parameter(Mandatory = $true, ParameterSetName="AzCopy")]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetSasTokenKey,

        [Parameter(Mandatory = $true, ParameterSetName="AzStorageBlobCopy")]
        [Parameter(Mandatory = $true, ParameterSetName="AzCopy")]
        [ValidateNotNullOrEmpty()]
        [Microsoft.WindowsAzure.Commands.Storage.AzureStorageContext]
        $TargetStorageContext
    )

    $ErrorActionPreference = "Stop"

    $destinationVhdFileName = "$SourceDiskName.vhd"
    [System.IO.Path]::GetInvalidFileNameChars() | ForEach-Object {$destinationVhdFileName = $destinationVhdFileName.replace($_,'_')}

    if ($PSCmdlet.ParameterSetName -eq "AzCopy")
    {
        Write-Verbose $Strings.MsgUseAzCopy -Verbose

        $localVhdFileName = Join-Path -Path $VhdLocalFolder -ChildPath $destinationVhdFileName
        Write-Verbose ($Strings.MsgAzCopyDownloadVHD -f $SourceDiskName, $VhdLocalFolder) -Verbose
        & $AzCopyPath copy $SourceDiskSas $localVhdFileName | Write-Verbose -Verbose

        $targetContainerSasUri = "$TargetContainerUri/$destinationVhdFileName`?$TargetSasTokenKey"
        Write-Verbose ($Strings.MsgAzCopyUploadVHD -f $SourceDiskName, $VhdLocalFolder, $TargetContainerName) -Verbose
        & $AzCopyPath copy $localVhdFileName $targetContainerSasUri | Write-Verbose -Verbose

        try
        {
            Remove-Item -Path $localVhdFileName -Force
        }
        catch
        {
            Write-Warning ($Strings.WarningFailToDeleteLocalVhdFile -f $localVhdFileName, $_) 
        }
    }

    if ($PSCmdlet.ParameterSetName -eq "AzStorageBlobCopy")
    {
        Write-Verbose $Strings.MsgUseAzStorageBlobCopy -Verbose
        $activityName = $Strings.MsgAzStorageBlobCopyActivity -f $SourceDiskName, $TargetContainerName
        $copyBlobResult = Start-AzStorageBlobCopy -AbsoluteUri $SourceDiskSas -DestContainer $TargetContainerName -DestContext $TargetStorageContext -DestBlob $destinationVhdFileName
        do
        {
            $copyBlobStatus = $copyBlobResult | Get-AzStorageBlobCopyState
            Write-Progress -Activity $activityName -Status $copyBlobStatus.Status -PercentComplete (($copyBlobStatus.BytesCopied / $copyBlobStatus.TotalBytes) * 100)
            Start-Sleep 10
        } while ($copyBlobStatus.Status -eq "Pending")
    }

    $null = Get-AzStorageBlob -Blob $destinationVhdFileName -Container $TargetContainerName -Context $TargetStorageContext

    return "$TargetContainerUri/$destinationVhdFileName"
}

<#
 .Synopsis
  Copy VHDs of disks attached to the specified VM to the target blob container.

 .Description
  - Stop the source VM if it's not deallocated
  - Copy the VHD of each disk attached to the source VM to the target blob container
  - If VhdLocalFolder is provided, AzCopy is used, and the VHDs will first be downloaded to VhdLocalFolder and then uploaded
  - If VhdLocalFolder is not provided, StorageBlobCopy is used
  - Return the uri of copied VHDs.

 .Example
  $VHDs = Copy-AzSiteRecoveryVmVHD -SourceVM $sourceVM -TargetStorageAccountName $targetStorageAccountName -TargetEnvironmentName "AzureStackUser" -TargetStorageAccountKey $targetStorageAccountKey
  $VHDs = Copy-AzSiteRecoveryVmVHD -SourceVM $sourceVM -TargetStorageAccountName $targetStorageAccountName -TargetEnvironmentName "AzureStackUser" -TargetStorageAccountSasToken $targetStorageAccountSasToken
  $VHDs = Copy-AzSiteRecoveryVmVHD -SourceVM $sourceVM -TargetStorageAccountName $targetStorageAccountName -TargetEndpoint $AzureStackEndpoint -TargetStorageAccountKey $targetStorageAccountKey
  $VHDs = Copy-AzSiteRecoveryVmVHD -SourceVM $sourceVM -TargetStorageAccountName $targetStorageAccountName -TargetEndpoint $AzureStackEndpoint -TargetStorageAccountSasToken $targetStorageAccountSasToken
  $VHDs = Copy-AzSiteRecoveryVmVHD -SourceVM $sourceVM -TargetStorageAccountName $targetStorageAccountName -TargetEnvironmentName "AzureStackUser" -TargetStorageAccountKey $targetStorageAccountKey -AzCopyPath $azCopyPath -VhdLocalFolder $vhdFolder -MaxRetry 6
  $VHDs = Copy-AzSiteRecoveryVmVHD -SourceVM $sourceVM -TargetStorageAccountName $targetStorageAccountName -TargetEnvironmentName "AzureStackUser" -TargetStorageAccountSasToken $targetStorageAccountSasToken -AzCopyPath $azCopyPath -VhdLocalFolder $vhdFolder -Force
#>
function Copy-AzSiteRecoveryVmVHD
{
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    [OutputType([String[]])]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [Microsoft.Azure.Commands.Compute.Models.PSVirtualMachine]
        $SourceVM,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetStorageAccountName,

        [Parameter(Mandatory = $true, ParameterSetName="Key_Endpoint")]
        [Parameter(Mandatory = $true, ParameterSetName="Key_Env")]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetStorageAccountKey,
        
        [Parameter(Mandatory = $true, ParameterSetName="Sas_Endpoint")]
        [Parameter(Mandatory = $true, ParameterSetName="Sas_Env")]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetStorageAccountSasToken,

        [Parameter(Mandatory = $true, ParameterSetName="Key_Endpoint")]
        [Parameter(Mandatory = $true, ParameterSetName="Sas_Endpoint")]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetStorageEndpoint,

        [Parameter(Mandatory = $true, ParameterSetName="Key_Env")]
        [Parameter(Mandatory = $true, ParameterSetName="Sas_Env")]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetEnvironmentName,

        [Parameter(Mandatory = $false)]
        [ValidateScript({$_ | Test-Path -IsValid})]
        [String]
        $AzCopyPath,

        [Parameter(Mandatory = $false)]
        [ValidateScript({$_ | Test-Path -IsValid})]
        [String]
        $VhdLocalFolder,

        [Parameter(Mandatory = $false)]
        [Int32]
        $MaxRetry = 3,

        [Parameter(Mandatory = $false)]
        [Switch]
        $Force
    )

    $ErrorActionPreference = "Stop"

    if ($PSBoundParameters.ContainsKey('AzCopyPath') -and $PSBoundParameters.ContainsKey('VhdLocalFolder'))
    {
        if (!(Test-Path $AzCopyPath -PathType Leaf))
        {
            throw ($Strings.ErrorAzCopyPathInvalid -f $AzCopyPath)
        }

        if (!(Test-Path $VhdLocalFolder -PathType Container))
        {
            Write-Verbose ($Strings.MsgCreateVhdFolder -f $VhdLocalFolder) -Verbose
            $null = New-Item -Path $VhdLocalFolder -ItemType "directory"
        }

        $env:AZCOPY_DEFAULT_SERVICE_API_VERSION = $AzCopyServiceAPIVersion
        $useAzCopy = $true
    }
    elseif ($PSBoundParameters.ContainsKey('AzCopyPath') -or $PSBoundParameters.ContainsKey('VhdLocalFolder'))
    {
        throw ($Strings.ErrorAzCopyParameterNotProvided)
    }
    else
    {
        $useAzCopy = $false
    }

    Write-Verbose $Strings.ProgressGetDiskInfo -Verbose
    $sourceVMName = $SourceVM.Name
    Write-Verbose ($Strings.MsgVmName -f $sourceVMName) -Verbose
    $sourceVMResourceGroupName = $SourceVM.ResourceGroupName
    Write-Verbose ($Strings.MsgVmResourceGroup -f $sourceVMResourceGroupName) -Verbose
    $osDiskId = $SourceVM.StorageProfile.OSDisk.ManagedDisk.Id
    $osDiskName = $SourceVM.StorageProfile.OSDisk.Name
    Write-Verbose ($Strings.MsgOsDiskName -f $osDiskName) -Verbose
    $dataDiskIds = $SourceVM.StorageProfile.DataDisks.ManagedDisk.Id
    $dataDiskNames = $SourceVM.StorageProfile.DataDisks.Name
    Write-Verbose ($Strings.MsgDataDiskNames -f ($dataDiskNames -join ", ")) -Verbose

    if ($dataDiskNames.Count -gt 0)
    {
        $diskIds = @($osDiskId) + @($dataDiskIds)
        $diskNames = @($osDiskName) + @($dataDiskNames)
    }
    else
    {
        $diskIds = @($osDiskId)
        $diskNames = @($osDiskName)
    }

    $targetContainerName = ("asrfailback-$sourceVMName-vhds").ToLower()

    Write-Verbose ($Strings.ProgressGetTargetStorageContext) -Verbose

    if ($PSCmdlet.ParameterSetName -eq "Key_Endpoint")
    {
        $targetStorageContext = New-AzStorageContext -Endpoint $TargetStorageEndpoint -StorageAccountName $TargetStorageAccountName -StorageAccountKey $TargetStorageAccountKey
    }
    elseif ($PSCmdlet.ParameterSetName -eq "Key_Env")
    {
        $targetStorageContext = New-AzStorageContext -Environment $TargetEnvironmentName -StorageAccountName $TargetStorageAccountName -StorageAccountKey $TargetStorageAccountKey
    }
    elseif ($PSCmdlet.ParameterSetName -eq "Sas_Endpoint")
    {
        $targetStorageContext = New-AzStorageContext -Endpoint $TargetStorageEndpoint -StorageAccountName $TargetStorageAccountName -SasToken $TargetStorageAccountSasToken
    }
    elseif ($PSCmdlet.ParameterSetName -eq "Sas_Env")
    {
        $targetStorageContext = New-AzStorageContext -Environment $TargetEnvironmentName -StorageAccountName $TargetStorageAccountName -SasToken $TargetStorageAccountSasToken
    }

    $targetContainer = Get-AzStorageContainer -Name $targetContainerName -Context $targetStorageContext -ErrorAction SilentlyContinue
    if ($null -eq $targetContainer)
    {
        Write-Verbose ($Strings.MsgCreateNewContainer -f $targetContainerName) -Verbose
        $targetContainer = New-AzStorageContainer -Name $targetContainerName -Context $targetStorageContext -Permission Off
    }

    if ($PSBoundParameters.ContainsKey('TargetStorageAccountKey'))
    {
        $targetContainerSasUri = New-AzStorageContainerSASToken -Context $targetStorageContext -ExpiryTime((Get-Date).ToUniversalTime()).AddSeconds($SasExpiryDuration) -FullUri -Name $targetContainerName -Permission rw
        $targetContainerUri, $targetSasTokenKey = $targetContainerSasUri -split "\?"
    }
    elseif ($PSBoundParameters.ContainsKey('TargetStorageAccountSasToken'))
    {
        $targetContainerUri = $targetContainer.CloudBlobContainer.Uri
        $targetSasTokenKey = $TargetStorageAccountSasToken
        if ($targetSasTokenKey.Contains('?'))
        {
            $targetSasTokenKey = $targetSasTokenKey.Substring($targetSasTokenKey.IndexOf('?') + 1, $targetSasTokenKey.Length - $targetSasTokenKey.IndexOf('?') - 1)
        }
    }

    $sourceVMDetail = Get-AzVM -ResourceGroupName $sourceVMResourceGroupName -Name $sourceVMName -Status
    $sourceVMStatus = $sourceVMDetail.Statuses[-1].Code
    if ($sourceVMStatus -ne "PowerState/deallocated")
    {
        Write-Verbose ($Strings.ProgressStopVM -f $sourceVMName) -Verbose
        if ($PSCmdlet.ShouldProcess("sourceVM $sourceVMName", "StopVM") -and
            ($Force.IsPresent -or $PSCmdlet.ShouldContinue($Strings.MsgShouldContinueStopVMConfirm, $Strings.MsgShouldContinueStopVMOperation)))
        {
            $stopResult = Stop-AzVM -ResourceGroupName $sourceVMResourceGroupName -Name $sourceVMName -Force -Confirm:$false
            if ($stopResult.Status -ne "Succeeded")
            {
                throw ($Strings.ErrorStopVmFail -f $sourceVMName, $stopResult.Error.Message)
            }
        }
        else
        {
            throw ($Strings.ErrorStopVmCancel -f $sourceVMName)
        }
    }

    $returnVhdUri = @()

    for ($diskNo = 0; $diskNo -lt $diskIds.Count; $diskNo++)
    {
        $diskResourceGroupName = (Get-AzResource -ResourceId $diskIds[$diskNo]).ResourceGroupName
        $diskName = $diskNames[$diskNo]
        Write-Verbose ($Strings.ProgressCopyVHD -f $diskName, $targetContainerName) -Verbose

        $sourceDiskSas = (Grant-AzDiskAccess -ResourceGroupName $diskResourceGroupName -DiskName $diskName -DurationInSecond $SasExpiryDuration -Access Read).AccessSAS

        $tryCount = 0
        while ($true)
        {
            $tryCount += 1
            Write-Verbose ($Strings.MsgCopyVHDTryTime -f $diskName, $tryCount) -Verbose

            try
            {
                if ($useAzCopy)
                {
                    $vhdUri = Copy-DiskVhd -SourceDiskName $diskName -SourceDiskSas $sourceDiskSas `
                                        -TargetContainerName $targetContainerName `
                                        -TargetContainerUri $targetContainerUri `
                                        -AzCopyPath $AzCopyPath `
                                        -VhdLocalFolder $VhdLocalFolder `
                                        -TargetSasTokenKey $targetSasTokenKey `
                                        -TargetStorageContext $targetStorageContext
                }
                else
                {
                    $vhdUri = Copy-DiskVhd -SourceDiskName $diskName -SourceDiskSas $sourceDiskSas `
                                        -TargetContainerName $targetContainerName `
                                        -TargetContainerUri $targetContainerUri `
                                        -TargetStorageContext $targetStorageContext
                }

                break
            }
            catch
            {
                if ($tryCount -le $MaxRetry)
                {
                    Write-Warning ($Strings.WarningFailToCopyVHD -f $diskName, $tryCount, $SleepTime, $_)
                    Start-Sleep -Seconds $SleepTime
                }
                else
                {
                    throw ($Strings.ErrorFailToCopyVHD -f $diskName, $_)
                }
            }
        }
        
        $null = Revoke-AzDiskAccess -ResourceGroupName $diskResourceGroupName -DiskName $diskName -ErrorAction SilentlyContinue
        
        $returnVhdUri += $vhdUri
    }

    return $returnVhdUri
}

# Formats JSON in a nicer format than the built-in ConvertTo-Json does
function Format-Json
{
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $Json
    )

    $indent = 0
    ($Json -Split "`n" | ForEach-Object {
        if ($_ -match '[\}\]]\s*,?\s*$') {
            # This line ends with ] or }, decrement the indentation level
            $indent--
        }

        $line = ('  ' * $indent) + $($_.TrimStart() -replace '":  (["{[])', '": $1' -replace ':  ', ': ')
        if ($_ -match '[\{\[]\s*$') {
            # This line ends with [ or {, increment the indentation level
            $indent++
        }

        $line
    }) -Join "`n"
}

function Compare-DiskUriName
{
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $DiskUri,

        [Parameter(Mandatory = $true)]
        [Int32]
        $DiskNo,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $DiskName
    )

    $blobName = [System.IO.Path]::GetFileNameWithoutExtension($DiskUri)

    [System.IO.Path]::GetInvalidFileNameChars() | ForEach-Object {$DiskName = $DiskName.replace($_,'_')}

    if ($blobName -ne $DiskName)
    {
        throw ($Strings.ErrorWrongSourceDiskVhdUri -f $DiskNo, $DiskName)
    }
}

<#
 .Synopsis
  Generate ARM template based on source VM, disk URIs and target environment.

 .Description
  - Get information of related resources, including disks, network, and storage account
  - Generate a parameter file to the given path
  - Generate a template file to the given path
  - Return the paths to the generated files.

 .Example
  Prepare-AzSiteRecoveryVMFailBack -SourceContextName $sourceContextName -SourceVM $sourceVM -SourceDiskVhdUris $uris -TargetResourceLocation $location -TargetContextName $targetContextName -ArmTemplateDestinationPath $path
  Prepare-AzSiteRecoveryVMFailBack -SourceContextName $sourceContextName -SourceVM $sourceVM -SourceDiskVhdUris $uris -TargetResourceLocation $location -TargetVM $targetVM -TargetContextName $targetContextName -ArmTemplateDestinationPath $path
#>
function Prepare-AzSiteRecoveryVMFailBack
{
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact = 'Medium')]
    [OutputType([String[]])]
    param(
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $SourceContextName,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [Microsoft.Azure.Commands.Compute.Models.PSVirtualMachine]
        $SourceVM,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String[]]
        $SourceDiskVhdUris,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetResourceLocation,

        [Parameter(Mandatory = $true, ParameterSetName="ReplaceExisting")]
        [ValidateNotNullOrEmpty()]
        [Microsoft.Azure.Commands.Compute.Models.PSVirtualMachine]
        $TargetVM,

        [Parameter(Mandatory = $true, ParameterSetName="ReplaceExisting")]
        [Parameter(Mandatory = $true, ParameterSetName="CreateNew")]
        [ValidateNotNullOrEmpty()]
        [String]
        $TargetContextName,

        [Parameter(Mandatory = $true)]
        [ValidateScript({$_ | Test-Path -IsValid})]
        [String]
        $ArmTemplateDestinationPath,

        [Parameter(Mandatory = $false)]
        [Switch]
        $Force
    )

    $ErrorActionPreference = "Stop"

    # Prepare for output files
    if (!(Test-Path $ArmTemplateDestinationPath -PathType Container))
    {
        Write-Verbose ($Strings.MsgCreateTemplateDestFolder -f $ArmTemplateDestinationPath) -Verbose
        $null = New-Item -Path $ArmTemplateDestinationPath -ItemType "directory"
    }

    $vmName = $SourceVM.Name

    $parameterFilePath = Join-Path -Path $ArmTemplateDestinationPath -ChildPath "$vmName-ParameterFile.json"
    $templateFilePath = Join-Path -Path $ArmTemplateDestinationPath -ChildPath "$vmName-TemplateFile.json"
    $outputFilePaths = @($parameterFilePath, $templateFilePath)

    foreach ($outputFilePath in $outputFilePaths)
    {
        if (!(Test-Path $outputFilePath -PathType Leaf) -or 
            ($PSCmdlet.ShouldProcess("$outputFilePath", "Overwrite") -and
            ($Force.IsPresent -or $PSCmdlet.ShouldContinue(($Strings.MsgShouldContinueOverwriteConfirm -f $outputFilePath), $Strings.MsgShouldContinueOverwriteOperation))))
        {
            $null = New-Item -Path $outputFilePath -ItemType "file" -Force -Confirm:$false
        }
        else
        {
            throw ($Strings.ErrorOverwriteFileCancel -f $outputFilePath)
        }
    }
    
    # Template variables
    $templateFile = [ordered]@{
        "`$schema" = "http://schema.management.azure.com/schemas/$schemaVersion/deploymentTemplate.json#"
        contentVersion = "1.0.0.0"
        parameters = [ordered]@{
            location = @{
                type = "String"
            }
            vmName = @{
                type = "String"
            }
            vmSize = @{
                type = "String"
            }
            storageAccountSkuName = @{
                type = "String"
            }
            diskCreateOption = @{
                type = "String"
            }
            osDiskName = @{
                type = "String"
            }
            osType = @{
                type = "String"
            }
            osDiskCaching = @{
                type = "String"
            }
            osDiskSourceUri = @{
                type = "String"
            }
        }
        resources = @($OsDiskTemplating)
    }

    $vmTemplating = [ordered]@{
        type = "Microsoft.Compute/virtualMachines"
        name = "[parameters('vmName')]"
        apiVersion = $VmArmAPIVersion
        location = "[parameters('location')]"
        properties = [ordered]@{
            hardwareProfile = [ordered]@{
                vmSize = "[parameters('vmSize')]"
            }
            storageProfile = [ordered]@{
                osDisk = $OsDiskStorageProfile
            }
            networkProfile = [ordered]@{
                networkInterfaces = @()
            }
        }
        dependsOn = @(
            "[resourceId('Microsoft.Compute/disks/', parameters('osDiskName'))]"
        )
    }

    $networkInterfaceTemplating = [ordered]@{
        type = "Microsoft.Network/networkInterfaces"
        name = "[parameters('networkInterfaceName')]"
        apiVersion = $NetworkArmAPIVersion
        location = "[parameters('location')]"
        properties = [ordered]@{
            ipConfigurations = @(
                [ordered]@{
                    name = "[parameters('ipConfigurationName')]"
                    properties = [ordered]@{
                        subnet = [ordered]@{
                            id = "[concat(resourceId('Microsoft.Network/virtualNetworks/', parameters('virtualNetworkName')), '/subnets/', parameters('subnetName'))]"
                        }
                        privateIPAllocationMethod = "[parameters('privateIPAllocationMethod')]"
                        privateIPAddress = "[parameters('privateIPAddress')]"
                        privateIPAddressVersion = "[parameters('privateIPAddressVersion')]"
                    }
                }
            )
        }
        dependsOn = @("[resourceId('Microsoft.Network/virtualNetworks/', parameters('virtualNetworkName'))]")
    }

    # Get info from source VM
    $null = Get-AzContext -Name $SourceContextName | Set-AzContext
    
    # VM basic info and OS disk
    $vmSize = $SourceVM.HardwareProfile.VmSize

    $osDiskName = $SourceVM.StorageProfile.OsDisk.Name
    $osDiskSourceUri = $SourceDiskVhdUris[0]
    [String]$osType = $sourceVM.StorageProfile.OsDisk.OsType
    [String]$osDiskCaching = $sourceVM.StorageProfile.OsDisk.Caching

    $null = Compare-DiskUriName -DiskUri $osDiskSourceUri -DiskNo 0 -DiskName $osDiskName

    # Storage account type
    [String]$storageAccountSkuName = $SourceVM.StorageProfile.OsDisk.ManagedDisk.StorageAccountType
    # When sourceVM is deallocated
    if ([String]::IsNullOrEmpty($storageAccountSkuName)) 
    {
        $storageAccountSkuName = (Get-AzResource -ResourceId $SourceVM.StorageProfile.OsDisk.ManagedDisk.Id).Sku.Name
    }

    if (!($storageAccountSkuName -like "*_*")) 
    {
        if ($storageAccountSkuName.Length -ge 8) 
        {
            $storageAccountSkuName = $storageAccountSkuName.Insert($storageAccountSkuName.Length - 3, "_")
        } 
        else 
        {
            throw ($Strings.ErrorInvalidStorageAccountType -f $SourceVM.Name)
        }
    }

    # Parameter file content variable
    $parametersFile = [ordered]@{
        "`$schema" = "https://schema.management.azure.com/schemas/$SchemaVersion/deploymentParameters.json#"
        contentVersion = "1.0.0.0"
        parameters = [ordered]@{
            location = @{
                value = $TargetResourceLocation
            }
            vmName = @{
                value = $vmName
            }
            vmSize = @{
                value = $vmSize
            }
            storageAccountSkuName = @{
                value = $storageAccountSkuName
            }
            diskCreateOption = @{
                value = "Attach"
            }
            osDiskName = @{
                value = $osDiskName
            }
            osType = @{
                value = $osType
            }
            osDiskCaching = @{
                value = $osDiskCaching
            }
            osDiskSourceUri = @{
                value = $osDiskSourceUri
            }
        }
    }

    # Data disks
    $dataDiskLuns = $SourceVM.StorageProfile.DataDisks.Lun

    if ($SourceDiskVhdUris.Count -ne ($dataDiskLuns.Count + 1))
    {
        throw ($Strings.ErrorWrongSourceDiskVhdUrisCount -f ($dataDiskLuns.Count + 1), $SourceDiskVhdUris.Count)
    }

    if ($dataDiskLuns.Count -gt 0)
    {
        $dataDiskNames = $SourceVM.StorageProfile.DataDisks.Name
        $dataDiskSourceUris = $SourceDiskVhdUris[1..($SourceDiskVhdUris.Count - 1)]
        $dataDiskSizeGB = $SourceVM.StorageProfile.DataDisks.DiskSizeGB

        $dependsOnDataDisk = @()
        for ($dataDiskNo = 0; $dataDiskNo -lt $dataDiskLuns.Count; $dataDiskNo++)
        {
            $dataDiskName = @($dataDiskNames)[$dataDiskNo]
            $null = Compare-DiskUriName -DiskUri $dataDiskSourceUris[$dataDiskNo] -DiskNo ($dataDiskNo + 1) -DiskName $dataDiskName

            $dependsOnDataDisk += "[resourceId('Microsoft.Compute/disks/', parameters('dataDiskNames')[$dataDiskNo])]"
        }

        # When sourceVM is deallocated, get disk size by getting disks first
        if (!($dataDiskSizeGB -match '[0-9]'))
        {
            $dataDiskIds = $SourceVM.StorageProfile.DataDisks.ManagedDisk.Id
            $dataDiskSizeGB = @()

            foreach ($dataDiskId in $dataDiskIds)
            {
                $dataDiskSizeGB += (Get-AzResource -ResourceId $dataDiskId).Properties.diskSizeGB
            }
        }

        $templateFile["parameters"] += [ordered]@{
            dataDiskLuns = @{
                type = "Array"
            }
            dataDiskNames = @{
                type = "Array"
            }
            dataDiskSourceUri = @{
                type = "Array"
            }
            dataDiskSizeGB = @{
                type = "Array"
            }
        }

        $parametersFile["parameters"] += [ordered]@{
            dataDiskLuns = @{
                value = @($dataDiskLuns)
            }
            dataDiskNames = @{
                value = @($dataDiskNames)
            }
            dataDiskSourceUri = @{
                value = @($dataDiskSourceUris)
            }
            dataDiskSizeGB = @{
                value = @($dataDiskSizeGB)
            }
        }

        $templateFile["resources"] += $DataDiskTemplating
        $vmTemplating["properties"]["storageProfile"] += $DataDiskStorageProfile
        $vmTemplating["dependsOn"] += $dependsOnDataDisk
    }
    
    # Network
    if ($PSCmdlet.ParameterSetName -eq "ReplaceExisting")
    {
        $nicObjects = $TargetVM.NetworkProfile.NetworkInterfaces
        foreach ($nicObject in $nicObjects)
        {
            $primary = $nicObject.primary
            if($null -eq $primary)
            {
                $primary = $false
            }

            $vmTemplating["properties"]["networkProfile"]["networkInterfaces"] += [ordered]@{
                id = $nicObject.Id
                properties = @{
                    primary = $primary
                }
            }
        }
    }
    else
    {
        $nicObjectId = ($SourceVM.NetworkProfile.NetworkInterfaces | Where-Object {$_.Primary -eq $true}).Id
        if($null -eq $nicObjectId)
        {
            $nicObjectId = $SourceVM.NetworkProfile.NetworkInterfaces[0].Id
        }

        $nicObject = Get-AzResource -ResourceId $nicObjectId
        $networkInterfaceName =  $nicObject.Name

        $ipConfig = $nicObject.Properties.ipConfigurations | Where-Object {$_.properties.primary -eq $true}
        if($null -eq $ipConfig)
        {
            $ipConfig = $nicObject.Properties.ipConfigurations[0]
        }

        $ipConfigurationName = $ipConfig.Name

        $privateIPAllocationMethod = $ipConfig.Properties.PrivateIPAllocationMethod
        $privateIPAddress = $ipConfig.Properties.PrivateIPAddress
        $privateIPAddressVersion = $ipConfig.Properties.PrivateIPAddressVersion

        if ($null -ne $ipConfig.Properties.PublicIPAddress)
        {
            $publicIpObject = Get-AzResource -ResourceId $ipConfig.Properties.PublicIPAddress.Id
            $publicIpAddressName = $publicIpObject.Name
            $publicIPAllocationMethod = $publicIpObject.Properties.PublicIPAllocationMethod
            $idleTimeoutInMinutes = $publicIpObject.Properties.IdleTimeoutInMinutes
            $publicIpAddressVersion = $publicIpObject.Properties.PublicIPAddressVersion

            $networkInterfaceTemplating["properties"]["ipConfigurations"][0]["properties"] += @{
                publicIpAddress = [ordered]@{
                    id = "[resourceId('Microsoft.Network/publicIPAddresses/', parameters('publicIpAddressName'))]"
                }
            }

            $networkInterfaceTemplating["dependsOn"] += "[resourceId('Microsoft.Network/publicIPAddresses/', parameters('publicIpAddressName'))]"

            $templateFile["parameters"] += [ordered]@{
                publicIpAddressName = @{
                    type = "String"
                }
                publicIpAddressSkuName = @{
                    type = "String"
                }
                publicIPAllocationMethod = @{
                    type = "String"
                }
                idleTimeoutInMinutes = @{
                    type = "Int"
                }
                publicIpAddressVersion = @{
                    type = "String"
                }
            }

            $parametersFile["parameters"] += [ordered]@{
                publicIpAddressName = @{
                    value = $publicIpAddressName
                }
                publicIpAddressSkuName = @{
                    value = "Basic"
                }
                publicIPAllocationMethod = @{
                    value = $publicIPAllocationMethod
                }
                idleTimeoutInMinutes = @{
                    value = $idleTimeoutInMinutes
                }
                publicIpAddressVersion = @{
                    value = $publicIpAddressVersion
                }
            }
            
            $templateFile["resources"] += $PublicIpAddressTemplating
        }

        $subnetId = $ipConfig.Properties.Subnet.Id
        $null = $subnetId -match '(.+/resourceGroups/)(?<virtualNetworkResourceGroupName>.+)(/providers/.+)(/VirtualNetworks/)(?<virtualNetworkName>.+)(/subnets/)(?<subnetName>.+)'
        $virtualNetworkName = $Matches.virtualNetworkName
        $virtualNetworkResourceGroupName = $Matches.virtualNetworkResourceGroupName
        $vnet = Get-AzVirtualNetwork -ResourceGroupName $virtualNetworkResourceGroupName -Name $virtualNetworkName
        $virtualNetworkAddressPrefixes = $vnet.AddressSpace.AddressPrefixes
        $subnetName = $Matches.subnetName
        $subnetConfig = Get-AzVirtualNetworkSubnetConfig -Name $subnetName -VirtualNetwork $vnet
        $subnetAddressPrefix = @($subnetConfig.AddressPrefix)[0]

        $templateFile["parameters"] += [ordered]@{
            networkInterfaceName = @{
                type = "String"
            }
            ipConfigurationName = @{
                type = "String"
            }
            privateIPAllocationMethod = @{
                type = "String"
            }
            privateIPAddress = @{
                type = "String"
            }
            privateIPAddressVersion = @{
                type = "String"
            }
            virtualNetworkName = @{
                type = "String"
            }
            virtualNetworkAddressPrefixes = @{
                type = "Array"
            }
            subnetName = @{
                type = "String"
            }
            subnetAddressPrefix = @{
                type = "String"
            }
        }

        $parametersFile["parameters"] += [ordered]@{
            networkInterfaceName = @{
                value = $networkInterfaceName
            }
            ipConfigurationName = @{
                value = $ipConfigurationName
            }
            privateIPAllocationMethod = @{
                value = $privateIPAllocationMethod
            }
            privateIPAddress = @{
                value = $privateIPAddress
            }
            privateIPAddressVersion = @{
                value = $privateIPAddressVersion
            }
            virtualNetworkName = @{
                value = $virtualNetworkName
            }
            virtualNetworkAddressPrefixes = @{
                value = @($virtualNetworkAddressPrefixes)
            }
            subnetName = @{
                value = $subnetName
            }
            subnetAddressPrefix = @{
                value = $subnetAddressPrefix
            }
        }

        $templateFile["resources"] += $VirtualNetworkTemplating
        $templateFile["resources"] += $networkInterfaceTemplating

        $vmTemplating["properties"]["networkProfile"]["networkInterfaces"] += @{
            id = "[resourceId('Microsoft.Network/networkInterfaces', parameters('networkInterfaceName'))]"
            properties = @{
                primary = $true
            }
        }
        
        $vmTemplating["dependsOn"] += "[resourceId('Microsoft.Network/networkInterfaces/', parameters('networkInterfaceName'))]"
    }

    # Boot diagnostics
    if ($PSCmdlet.ParameterSetName -eq "ReplaceExisting")
    {
        $bootDiagnosticsStorageUri = $TargetVM.DiagnosticsProfile.BootDiagnostics.storageUri
        $bootDiagnosticsEnabled = $TargetVM.DiagnosticsProfile.BootDiagnostics.Enabled
        if (![String]::IsNullOrEmpty($bootDiagnosticsStorageUri))
        {
            $templateFile["parameters"] += [ordered]@{
                bootDiagnosticsEnabled = @{
                    type = "Bool"
                }
                bootDiagnosticsStorageUri = @{
                    type = "String"
                }
            }

            $parametersFile["parameters"] += [ordered]@{
                bootDiagnosticsEnabled = @{
                    value = $bootDiagnosticsEnabled
                }
                bootDiagnosticsStorageUri = @{
                    value = $bootDiagnosticsStorageUri
                }
            }

            $vmTemplating["properties"] += $BootDiagnosticsTemplating
        }
    }
    else
    {
        $bootDiagnosticsStorageUri = $SourceVM.DiagnosticsProfile.BootDiagnostics.storageUri
        if (![String]::IsNullOrEmpty($bootDiagnosticsStorageUri))
        {
            $storageAccountName = $bootDiagnosticsStorageUri.Substring($bootDiagnosticsStorageUri.LastIndexOf("/") + 1, $bootDiagnosticsStorageUri.IndexOf(".") - $bootDiagnosticsStorageUri.LastIndexOf("/") - 1)
            $targetEndpoint = (Get-AzContext -Name $TargetContextName).Environment.StorageEndpointSuffix
            $bootDiagnosticsStorageUri = "https://$storageAccountName.blob.$targetEndpoint"
            $bootDiagnosticsEnabled = $SourceVM.DiagnosticsProfile.BootDiagnostics.Enabled

            $templateFile["parameters"] += [ordered]@{
                bootDiagnosticsEnabled = @{
                    type = "Bool"
                }
                bootDiagnosticsStorageUri = @{
                    type = "String"
                }
                storageAccountName = @{
                    type = "String"
                }
                storageAccountSupportsHttpsTrafficOnly = @{
                    type = "Bool"
                }
                storageAccountKind = @{
                    type = "String"
                }
            }

            $parametersFile["parameters"] += [ordered]@{
                bootDiagnosticsEnabled = @{
                    value = $bootDiagnosticsEnabled
                }
                bootDiagnosticsStorageUri = @{
                    value = $bootDiagnosticsStorageUri
                }
                storageAccountName = @{
                    value = $storageAccountName
                }
                storageAccountSupportsHttpsTrafficOnly = @{
                    value = $true
                }
                storageAccountKind = @{
                    value = "Storage"
                }
            }

            $templateFile["resources"] += $StorageAccountTemplating
            $vmTemplating["properties"] += $BootDiagnosticsTemplating
            $vmTemplating["dependsOn"] += "[resourceId('Microsoft.Storage/storageAccounts/', parameters('storageAccountName'))]"
        }
    }

    # Generate json files
    Write-Verbose ($Strings.MsgWriteIntoFile -f $parameterFilePath) -Verbose
    $parametersFile | ConvertTo-Json -Depth 5 | Format-Json | ForEach-Object { [System.Text.RegularExpressions.Regex]::Unescape($_) } | Out-File $parameterFilePath

    $templateFile["resources"] += $vmTemplating
    Write-Verbose ($Strings.MsgWriteIntoFile -f $templateFilePath) -Verbose
    $templateFile | ConvertTo-Json -Depth 10 | Format-Json | ForEach-Object { [System.Text.RegularExpressions.Regex]::Unescape($_) } | Out-File $templateFilePath

    # Display info of new disk vhds
    Write-Verbose ($Strings.MsgSourceDiskVhdUris -f ($SourceDiskVhdUris -join ", ")) -Verbose

    $null = Get-AzContext -Name $TargetContextName | Set-AzContext

    # If replace existing VM, ask to delete the target VM
    if ($PSCmdlet.ParameterSetName -eq "ReplaceExisting")
    {
        Write-Verbose ($Strings.MsgDisksAttachedToTheVMToBeDeleted -f $TargetVM.Name) -Verbose
        $osDiskName = $TargetVM.StorageProfile.OSDisk.Name
        Write-Verbose ($Strings.MsgOsDiskName -f $osDiskName) -Verbose
        $dataDiskNames = $TargetVM.StorageProfile.DataDisks.Name
        Write-Verbose ($Strings.MsgDataDiskNames -f ($dataDiskNames -join ", ")) -Verbose

        if ($PSCmdlet.ShouldProcess($TargetVM.Name, ($Strings.MsgDeleteVMOperationName)) -and
            ($Force.IsPresent -or $PSCmdlet.ShouldContinue(($Strings.MsgShouldContinueDeleteVMConfirm -f $TargetVM.Name), $Strings.MsgShouldContinueDeleteVMOperation)))
        {
            $null = Remove-AzVM -Name $TargetVM.Name -ResourceGroupName $TargetVM.ResourceGroupName -Force -Confirm:$false
        }
        else
        {
            throw ($Strings.ErrorDeleteVMCancel -f $TargetVM.Name, $templateFilePath, $parameterFilePath)
        }
    }

    return @($templateFilePath, $parameterFilePath)
}

Export-ModuleMember -Function Copy-AzSiteRecoveryVmVHD
Export-ModuleMember -Function Prepare-AzSiteRecoveryVMFailBack

# SIG # Begin signature block
# MIIjhwYJKoZIhvcNAQcCoIIjeDCCI3QCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC/og5Jmb5S54Yj
# SxKLXcWQfgbQ22OrZvX00M+htV1NEaCCDXYwggX0MIID3KADAgECAhMzAAABhk0h
# daDZB74sAAAAAAGGMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAwMzA0MTgzOTQ2WhcNMjEwMzAzMTgzOTQ2WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC49eyyaaieg3Xb7ew+/hA34gqzRuReb9svBF6N3+iLD5A0iMddtunnmbFVQ+lN
# Wphf/xOGef5vXMMMk744txo/kT6CKq0GzV+IhAqDytjH3UgGhLBNZ/UWuQPgrnhw
# afQ3ZclsXo1lto4pyps4+X3RyQfnxCwqtjRxjCQ+AwIzk0vSVFnId6AwbB73w2lJ
# +MC+E6nVmyvikp7DT2swTF05JkfMUtzDosktz/pvvMWY1IUOZ71XqWUXcwfzWDJ+
# 96WxBH6LpDQ1fCQ3POA3jCBu3mMiB1kSsMihH+eq1EzD0Es7iIT1MlKERPQmC+xl
# K+9pPAw6j+rP2guYfKrMFr39AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUhTFTFHuCaUCdTgZXja/OAQ9xOm4w
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ1ODM4NDAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAEDkLXWKDtJ8rLh3d7XP
# 1xU1s6Gt0jDqeHoIpTvnsREt9MsKriVGKdVVGSJow1Lz9+9bINmPZo7ZdMhNhWGQ
# QnEF7z/3czh0MLO0z48cxCrjLch0P2sxvtcaT57LBmEy+tbhlUB6iz72KWavxuhP
# 5zxKEChtLp8gHkp5/1YTPlvRYFrZr/iup2jzc/Oo5N4/q+yhOsRT3KJu62ekQUUP
# sPU2bWsaF/hUPW/L2O1Fecf+6OOJLT2bHaAzr+EBAn0KAUiwdM+AUvasG9kHLX+I
# XXlEZvfsXGzzxFlWzNbpM99umWWMQPTGZPpSCTDDs/1Ci0Br2/oXcgayYLaZCWsj
# 1m/a0V8OHZGbppP1RrBeLQKfATjtAl0xrhMr4kgfvJ6ntChg9dxy4DiGWnsj//Qy
# wUs1UxVchRR7eFaP3M8/BV0eeMotXwTNIwzSd3uAzAI+NSrN5pVlQeC0XXTueeDu
# xDch3S5UUdDOvdlOdlRAa+85Si6HmEUgx3j0YYSC1RWBdEhwsAdH6nXtXEshAAxf
# 8PWh2wCsczMe/F4vTg4cmDsBTZwwrHqL5krX++s61sLWA67Yn4Db6rXV9Imcf5UM
# Cq09wJj5H93KH9qc1yCiJzDCtbtgyHYXAkSHQNpoj7tDX6ko9gE8vXqZIGj82mwD
# TAY9ofRH0RSMLJqpgLrBPCKNMIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCFWcwghVjAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAGGTSF1oNkHviwAAAAAAYYwDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIJshwTJOQYlRcGjmUvHVfqzS
# SgWPUfnAQPMb5XgEY3PPMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEALqZiPyoGxhxySBbpfPT8KLoWZjYORVD4mT3JaQoLdfbfE702v4eyQ2R/
# /wDrbdBapaphkdIphbIS1IrzEsCiGP5BsQINzYBPmAhiwdShoKPiQG96B9kSNrc/
# sA2UDFc3mD1CjEmjpcUV1FH4uGm4Bczlc10dldF5JqZhu+mzDL2LDpqYQ3V+56KW
# Sy/+I7m3Z2r+3hibDIgqZ5AqxG7NWWjslZJ5L7cuy67B22glwTwB3W6pcMxaVH8X
# HpzXMpCDCqJSABdI1HXt142tog/3ChVLEgIokvGrc5lQj0Fb4OMErxSNzoObt47n
# mi9SfaCuj6W9Rv0OYE1KsrhY0+jmVaGCEvEwghLtBgorBgEEAYI3AwMBMYIS3TCC
# EtkGCSqGSIb3DQEHAqCCEsowghLGAgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFVBgsq
# hkiG9w0BCRABBKCCAUQEggFAMIIBPAIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCCr6JtZSAVahTeF0OIrFQGzs3V2MjwESrjIgMf5OUNM3QIGX2D6sYoB
# GBMyMDIwMDkyNDA2MDExNC42NzdaMASAAgH0oIHUpIHRMIHOMQswCQYDVQQGEwJV
# UzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UE
# ChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3Bl
# cmF0aW9ucyBQdWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QzRC
# RC1FMzdGLTVGRkMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZp
# Y2Wggg5EMIIE9TCCA92gAwIBAgITMwAAASM4sOSt2FqQnQAAAAABIzANBgkqhkiG
# 9w0BAQsFADB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4G
# A1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYw
# JAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDAeFw0xOTEyMTkw
# MTE0NTZaFw0yMTAzMTcwMTE0NTZaMIHOMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQdWVy
# dG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QzRCRC1FMzdGLTVGRkMx
# JTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqG
# SIb3DQEBAQUAA4IBDwAwggEKAoIBAQCdvNDJsGSl3AEu8dmbwOEzjgs8Put17PVC
# xlrXWQzd1ZfmhkBLDMBKyJIM0ItH0ztLDg/Td4TtR2k1h6EvNDf0G+qC0dlgmZL/
# 1TOFhZ04Tr98gOc0rfr7ijcK4xBxQtI5TAwiamlO0reliW5f5AD+bIDNKraRBEIc
# bVWn/CKFeZavL4DCTa99DuK6i2BIv2GVkGWMEBwIlTLpwmKSYnHJzTjUUXYNg908
# rttnhCcD0D+g5HhIqDMvXoTJga5IwA1ToEFfk+Joq/oQCXiDcrKbOsIETuao7lef
# o73MzUGtVpu48bKgb9OBgpSKeTR7610JmfZqWXY9648RbmWyo3dxAgMBAAGjggEb
# MIIBFzAdBgNVHQ4EFgQUgdRsFIDTjRv5EcKwaN4ZFfgMnh4wHwYDVR0jBBgwFoAU
# 1WM6XIoxkPNDe3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2Ny
# bC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIw
# MTAtMDctMDEuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDov
# L3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0w
# Ny0wMS5jcnQwDAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkq
# hkiG9w0BAQsFAAOCAQEAW+UBt6pX6Fuq9VeJU/pDvC1Mxd9kt31H4J/0tUEAT8zk
# bP+ro49PcrR1jQ3znsMJEsmtX/EvXvgW515Jx+Zd0ep0tgZEUwDbU5l8bzC0wsr3
# mHvyUCH6LPmd4idG9ahw0pxI+kJnX9TMpqzwJOY8YcYYol5cCC1I7x+esu6yx8St
# MJ7B9dhDvTJ5GkjVyTQpkpn4FBJAzc7udwt/ZelzUQD2rs9v1rJSFGXF9zQwjIL+
# YWYtp4XffR8cmiSbHJ9X/IWVwPvn9RzW6vG3ZIdzmIEZza+0HZzvhrr7bt3chqmH
# UDDBj5wLeC+xMPcpI8tFKM+uP69Em0CEWLcuXjPTNzCCBnEwggRZoAMCAQICCmEJ
# gSoAAAAAAAIwDQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmlj
# YXRlIEF1dGhvcml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1
# NVowfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18
# aEssX8XD5WHCdrc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdN
# uDgIs0Ldk6zWczBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NM
# ksHEpl3RYRNuKMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2K
# Qk1AUdEPnAY+Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZ
# zTznL0S6p/TcZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQ
# BgkrBgEEAYI3FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUw
# GQYJKwYBBAGCNxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB
# /wQFMAMBAf8wHwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0f
# BE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJv
# ZHVjdHMvTWljUm9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4w
# TDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0
# cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCB
# jwYJKwYBBAGCNy4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29m
# dC5jb20vUEtJL2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAd
# AEwAZQBnAGEAbABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAd
# MA0GCSqGSIb3DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F
# 4qn++ldtGTCzwsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbM
# QEBBm9xcF/9c+V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mB
# ZdmptWvkx872ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7ti
# X5rbV0Dp8c6ZZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S
# 4Zz5Hfw42JT0xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3ai
# caoGig+JFrphpxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf
# 5zEHpJM692VHeOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsb
# iSpUObJb2sgNVZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJ
# zxlBTeCG+SqaoxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB
# 0d4wwP3M5k37Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/e
# dIhJEqGCAtIwggI7AgEBMIH8oYHUpIHRMIHOMQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSkwJwYDVQQLEyBNaWNyb3NvZnQgT3BlcmF0aW9ucyBQ
# dWVydG8gUmljbzEmMCQGA1UECxMdVGhhbGVzIFRTUyBFU046QzRCRC1FMzdGLTVG
# RkMxJTAjBgNVBAMTHE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2WiIwoBATAH
# BgUrDgMCGgMVALoXZo3g4p4Xwu4MNSgQnjP7+1eBoIGDMIGApH4wfDELMAkGA1UE
# BhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAc
# BgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0
# IFRpbWUtU3RhbXAgUENBIDIwMTAwDQYJKoZIhvcNAQEFBQACBQDjFq2CMCIYDzIw
# MjAwOTI0MDkzMDQyWhgPMjAyMDA5MjUwOTMwNDJaMHcwPQYKKwYBBAGEWQoEATEv
# MC0wCgIFAOMWrYICAQAwCgIBAAICHlMCAf8wBwIBAAICEiowCgIFAOMX/wICAQAw
# NgYKKwYBBAGEWQoEAjEoMCYwDAYKKwYBBAGEWQoDAqAKMAgCAQACAwehIKEKMAgC
# AQACAwGGoDANBgkqhkiG9w0BAQUFAAOBgQB4TG0Ukb+7YM1IJmeOs1wpUhEhHsXG
# C6I8yodzgX+7bcQBn+NWdCTWgx8jOGI4ax0YxiBTfTL0n8iPMjr/4VpqU13lPIyM
# TO3+tQhtVjdmeH+gCJ4E/CLF3iHeN6caHze421DA8K/sGgm7BvcCpfpfeznySGFE
# ry3QVlClxh0uyTGCAw0wggMJAgEBMIGTMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQI
# EwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3Nv
# ZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBD
# QSAyMDEwAhMzAAABIziw5K3YWpCdAAAAAAEjMA0GCWCGSAFlAwQCAQUAoIIBSjAa
# BgkqhkiG9w0BCQMxDQYLKoZIhvcNAQkQAQQwLwYJKoZIhvcNAQkEMSIEIKSera/v
# 75eybKXgeduBIX4eaPz+Kd9ofP8ouk0d6SrmMIH6BgsqhkiG9w0BCRACLzGB6jCB
# 5zCB5DCBvQQgEZozgz/7RMzEDaOjrMSkAAy/KcCiZDOWJ1yq6vsVgbMwgZgwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMAITMwAAASM4sOSt2FqQnQAA
# AAABIzAiBCAZDH6S6OCK1aJwhbcc7IFmX4GjY6/e5GTQuPHylsGmODANBgkqhkiG
# 9w0BAQsFAASCAQBQTY2WYBTMBJE4BXS4zX0gcAholQtCh0NXaobDrIjM/eG5+8pv
# rmiu/kBAYc1GJxT6E0P85TH8/Jf4emDc/TAKGzK3SqOdWdhyj/EWJgwwm2sl/jb9
# Z+g/KhLhb27/douVmNXnfwuKwQWIRLJgV9Wqje79E5WewnNU/hvuQsRcsq/nANLw
# mJnYGaO5KRKMlcj0aY0otq7a6GESYXltIXzRSpTIWsoU7i3+dLcXgXgFFM6eD2ma
# Dsbp7W5nAcKyS/ZHh6bNWA3XmNvH/cwwp4H6I2/Zxs1vHtK559sfwbQGnaPSoYGj
# LkiaGEWzN2ZPfBkPdO8zj/6bBud4cgJPqx1x
# SIG # End signature block
